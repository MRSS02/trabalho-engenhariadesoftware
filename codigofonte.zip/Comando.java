interface Comando {
    void executar(String[] args);
}
