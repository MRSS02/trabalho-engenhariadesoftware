interface Observer {
    void update(int codigoLivro);
}
